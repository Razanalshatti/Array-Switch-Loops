import UIKit

// task Arrays

var bookCollection = ["Book1", "Book2", "Book3", "Book4"]

print("the number of books is \(bookCollection.count)")



bookCollection.append("Book5")
print("books array after appending \n \(bookCollection)")



bookCollection.insert("Book0", at: 0)
print("books array after inserting \n \(bookCollection)")


bookCollection.remove(at: 1)
print("books array after removing \n \(bookCollection)")

//

// task Loops

let favoriteFruits = ["Apple", "Banana", "Cherry"]


for fruit in favoriteFruits {
    print(fruit)
}

for i in 1...5 {
    
    for j in 1...5 {
        let result = i * j
        
        print("\(i) * \(j) = \(result)")
    }
}
//

// task switch

// Grades
let grade = "B"

switch grade {
case "A":
    print("Excellent")
case "B":
    print("Good")
case "C":
    print("Average")
case "D":
    print("Below Average")
case "F":
    print("Poor")
default:
    print("Invalid Grade")
}

// Traffic Light
let trafficLight = "red"

switch trafficLight {
case "red":
    print("Stop")
case "yellow":
    print("Get Ready")
case "green":
    print("Go")
default:
    print("Invalid Traffic Light Color")
}
